#include <stdio.h>
#include <math.h>
#include"naval.h"


//função para jogar realmente, onde os jogadores escolheram seus ataques, os tabuleiros serão printados, etc...
void jogar(Jogador* j1, Jogador* j2) {

    //define p1 e p2 para o tipo jogo, colocando as informações contidas do "naval.h"
    Jogo p1, p2;
    //relaciona as informações da função iniciar tabuleiro, vinda de "tabuleiro.c" e relaciona com os p1 e p2 em cada informação, guardando o mapa normal e o mapa com os tiros de cada jogador
    iniciarTabuleiro(p1.tabuleiro);
    iniciarTabuleiro(p1.tiros);
    iniciarTabuleiro(p2.tabuleiro);
    iniciarTabuleiro(p2.tiros);


int i;
int turno = 0;
    //while de divisão de turnos e ações dos jogadores.
    while("infinito"){
        if(turno % 2 ==0){
            mostraTabuleiro(p1.tabuleiro);
            turno++;
        }else if(turno % 2 != 0){
            mostraTabuleiro(p2.tabuleiro);
            turno++;
        }
    }
}