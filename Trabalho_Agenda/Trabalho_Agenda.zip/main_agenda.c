#include <stdio.h>
#include <stdlib.h>
#include "eventos.h"

int main(){
    menu();
}



