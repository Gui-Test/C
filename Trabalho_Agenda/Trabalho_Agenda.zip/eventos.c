#include <stdio.h>
#include <stdlib.h>
#include "eventos.h"

void cadastrar();
void mostrar_eventos();
void pesquisa_data();
void pesquisa_desc();
void remove_evento();