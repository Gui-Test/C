#include <stdio.h>
#include <stdlib.h>
#include "eventos.h"

//gcc main_agenda.c menu.c eventos.h eventos.c

int main(){
    menu();
}



