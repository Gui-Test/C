#include "header.h"
//gcc main.c header.h menu.c conjuntos.c

int main(){
    menu();


    return 0;   
}